import { describe, it, expect } from 'vitest';
import { parseDynamicLevelContent, DynamicContentParseError } from './parseDynamicContent';

function validPayload() {
  return JSON.stringify({
    stations: [
      { station: 'disiplin', instruction: 'Sudah minum air putih?', inputType: 'checklist' },
      {
        station: 'insting',
        instruction: 'Pilih cepat.',
        inputType: 'choice',
        choices: ['Opsi A', 'Opsi B'],
        timeLimitSeconds: 8,
      },
      {
        station: 'ketelitian',
        instruction: 'Cari kejanggalan.',
        inputType: 'findIssues',
        timeLimitSeconds: 45,
      },
      { station: 'mentalTangguh', instruction: 'Refleksi singkat.', inputType: 'text' },
      { station: 'percayaDiri', instruction: 'Tulis afirmasi.', inputType: 'text' },
    ],
  });
}

describe('parseDynamicLevelContent — happy path', () => {
  it('parses a well-formed response into a LevelContent object', () => {
    const result = parseDynamicLevelContent(validPayload(), 12, 'Putaran 12');
    expect(result.level).toBe(12);
    expect(result.title).toBe('Putaran 12');
    expect(result.stations).toHaveLength(5);
    expect(result.stations.map((s) => s.station)).toEqual([
      'disiplin',
      'insting',
      'ketelitian',
      'mentalTangguh',
      'percayaDiri',
    ]);
    expect(result.stations[1].choices).toEqual(['Opsi A', 'Opsi B']);
  });

  it('extracts JSON even when the model wraps it in prose', () => {
    const wrapped = `Tentu, ini sesinya:\n${validPayload()}\nSemoga membantu!`;
    const result = parseDynamicLevelContent(wrapped, 12, 'Putaran 12');
    expect(result.stations).toHaveLength(5);
  });

  it('assigns the correct human-readable title per station', () => {
    const result = parseDynamicLevelContent(validPayload(), 6, 'Putaran 6');
    expect(result.stations[0].title).toBe('Disiplin');
    expect(result.stations[4].title).toBe('Percaya Diri');
  });
});

describe('parseDynamicLevelContent — failure modes', () => {
  it('throws on completely non-JSON input', () => {
    expect(() => parseDynamicLevelContent('maaf, saya tidak bisa membuat ini', 6, 't')).toThrow(
      DynamicContentParseError
    );
  });

  it('throws on syntactically broken JSON', () => {
    expect(() => parseDynamicLevelContent('{"stations": [', 6, 't')).toThrow(
      DynamicContentParseError
    );
  });

  it('throws when fewer than 5 stations are returned', () => {
    const payload = JSON.stringify({
      stations: JSON.parse(validPayload()).stations.slice(0, 3),
    });
    expect(() => parseDynamicLevelContent(payload, 6, 't')).toThrow(/3 stasiun/);
  });

  it('throws when station order does not match the expected sequence', () => {
    const stations = JSON.parse(validPayload()).stations;
    [stations[0], stations[1]] = [stations[1], stations[0]]; // swap disiplin/insting
    const payload = JSON.stringify({ stations });
    expect(() => parseDynamicLevelContent(payload, 6, 't')).toThrow(/posisi 1/);
  });

  it('throws when a station is missing its instruction', () => {
    const stations = JSON.parse(validPayload()).stations;
    delete stations[0].instruction;
    const payload = JSON.stringify({ stations });
    expect(() => parseDynamicLevelContent(payload, 6, 't')).toThrow(/instruksi/);
  });

  it('throws on an unrecognized inputType', () => {
    const stations = JSON.parse(validPayload()).stations;
    stations[0].inputType = 'multiple_choice_grid';
    const payload = JSON.stringify({ stations });
    expect(() => parseDynamicLevelContent(payload, 6, 't')).toThrow(/inputType tidak dikenal/);
  });

  it('throws when a "choice" station has fewer than 2 choices', () => {
    const stations = JSON.parse(validPayload()).stations;
    stations[1].choices = ['Cuma satu'];
    const payload = JSON.stringify({ stations });
    expect(() => parseDynamicLevelContent(payload, 6, 't')).toThrow(/minimal 2 pilihan/);
  });

  it('throws when timeLimitSeconds is not a number', () => {
    const stations = JSON.parse(validPayload()).stations;
    stations[1].timeLimitSeconds = 'delapan detik';
    const payload = JSON.stringify({ stations });
    expect(() => parseDynamicLevelContent(payload, 6, 't')).toThrow(/timeLimitSeconds/);
  });
});
