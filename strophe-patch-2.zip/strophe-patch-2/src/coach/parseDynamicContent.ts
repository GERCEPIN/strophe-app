import type { StationId } from '../types';
import type { StationContent, LevelContent } from '../content/coreSessionLevels';

/**
 * Parses and validates the JSON response from
 * coach/promptTemplates.ts#dynamicLevelContentPrompt. Models can still
 * occasionally wrap valid JSON in prose despite explicit instructions not
 * to ("Sure, here's the session: {...}") — this extracts the JSON
 * substring defensively before parsing, then validates the shape field by
 * field so a malformed response produces a clear, specific error instead
 * of a confusing runtime crash deeper in the UI.
 */
export class DynamicContentParseError extends Error {}

const EXPECTED_STATIONS: StationId[] = [
  'disiplin',
  'insting',
  'ketelitian',
  'mentalTangguh',
  'percayaDiri',
];

const VALID_INPUT_TYPES: StationContent['inputType'][] = [
  'checklist',
  'choice',
  'findIssues',
  'text',
];

const STATION_TITLES: Record<StationId, string> = {
  disiplin: 'Disiplin',
  insting: 'Insting',
  ketelitian: 'Ketelitian',
  mentalTangguh: 'Mental Tangguh',
  percayaDiri: 'Percaya Diri',
};

interface RawStation {
  station?: unknown;
  instruction?: unknown;
  inputType?: unknown;
  choices?: unknown;
  timeLimitSeconds?: unknown;
}

interface RawResponse {
  stations?: unknown;
}

export function parseDynamicLevelContent(
  raw: string,
  level: number,
  title: string
): LevelContent {
  const jsonText = extractJsonSubstring(raw);

  let parsed: RawResponse;
  try {
    parsed = JSON.parse(jsonText) as RawResponse;
  } catch {
    throw new DynamicContentParseError('AI Coach tidak mengembalikan JSON yang valid.');
  }

  if (!Array.isArray(parsed.stations) || parsed.stations.length !== EXPECTED_STATIONS.length) {
    throw new DynamicContentParseError(
      `AI Coach mengembalikan ${
        Array.isArray(parsed.stations) ? parsed.stations.length : 0
      } stasiun, seharusnya ${EXPECTED_STATIONS.length}.`
    );
  }

  const stations: StationContent[] = EXPECTED_STATIONS.map((expected, i) => {
    const raw = parsed.stations as RawStation[];
    return validateStation(raw[i], expected, i);
  });

  return { level, title, stations };
}

function validateStation(s: RawStation, expected: StationId, index: number): StationContent {
  if (!s || s.station !== expected) {
    throw new DynamicContentParseError(
      `Urutan/nama stasiun tidak sesuai di posisi ${index + 1} (harus "${expected}", dapat "${String(s?.station)}").`
    );
  }
  if (typeof s.instruction !== 'string' || s.instruction.trim().length === 0) {
    throw new DynamicContentParseError(`Stasiun "${expected}" tidak punya instruksi yang valid.`);
  }
  if (typeof s.inputType !== 'string' || !VALID_INPUT_TYPES.includes(s.inputType as StationContent['inputType'])) {
    throw new DynamicContentParseError(
      `Stasiun "${expected}" punya inputType tidak dikenal: "${String(s.inputType)}".`
    );
  }
  if (s.inputType === 'choice') {
    if (!Array.isArray(s.choices) || s.choices.length < 2 || !s.choices.every((c) => typeof c === 'string')) {
      throw new DynamicContentParseError(`Stasiun "${expected}" (choice) butuh minimal 2 pilihan teks.`);
    }
  }
  if (s.timeLimitSeconds !== undefined && typeof s.timeLimitSeconds !== 'number') {
    throw new DynamicContentParseError(`Stasiun "${expected}" punya timeLimitSeconds yang bukan angka.`);
  }

  return {
    station: expected,
    title: STATION_TITLES[expected],
    instruction: s.instruction,
    inputType: s.inputType as StationContent['inputType'],
    choices: s.choices as string[] | undefined,
    timeLimitSeconds: s.timeLimitSeconds as number | undefined,
  };
}

function extractJsonSubstring(raw: string): string {
  const trimmed = raw.trim();
  if (trimmed.startsWith('{')) return trimmed;
  const start = trimmed.indexOf('{');
  const end = trimmed.lastIndexOf('}');
  if (start === -1 || end === -1 || end < start) {
    throw new DynamicContentParseError('Tidak ditemukan JSON di respons AI Coach.');
  }
  return trimmed.slice(start, end + 1);
}
