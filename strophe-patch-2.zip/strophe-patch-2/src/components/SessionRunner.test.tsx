import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { SessionRunner } from './SessionRunner';
import { createInitialProgressState } from '../engine/level';
import { resetAllData } from '../storage/db';
import { CoachClientError } from '../coach/client';

vi.mock('../coach/client', () => ({
  callCoach: vi.fn(),
  CoachClientError: class CoachClientError extends Error {},
}));

import { callCoach } from '../coach/client';

const mockedCallCoach = vi.mocked(callCoach);

function validDynamicPayload() {
  return JSON.stringify({
    stations: [
      { station: 'disiplin', instruction: 'Sudah minum air?', inputType: 'checklist' },
      {
        station: 'insting',
        instruction: 'Pilih cepat.',
        inputType: 'choice',
        choices: ['Opsi A', 'Opsi B'],
        timeLimitSeconds: 6,
      },
      { station: 'ketelitian', instruction: 'Cari kejanggalan.', inputType: 'findIssues', timeLimitSeconds: 40 },
      { station: 'mentalTangguh', instruction: 'Refleksi.', inputType: 'text' },
      { station: 'percayaDiri', instruction: 'Afirmasi.', inputType: 'text' },
    ],
  });
}

describe('SessionRunner — static levels (1-5)', () => {
  beforeEach(async () => {
    await resetAllData();
    mockedCallCoach.mockReset();
  });

  it('renders the first station immediately, with no loading state, for level 1', () => {
    const progress = createInitialProgressState(); // currentLevel 0 -> attempting level 1
    render(<SessionRunner progress={progress} onFinish={vi.fn()} onCancel={vi.fn()} />);
    expect(screen.getByText(/Putaran 1/)).toBeInTheDocument();
    expect(screen.queryByText(/menyiapkan sesi/)).not.toBeInTheDocument();
    expect(mockedCallCoach).not.toHaveBeenCalled();
  });

  it('walks through all 5 stations and calls onFinish with the advanced progress state', async () => {
    const progress = createInitialProgressState();
    const onFinish = vi.fn();
    render(<SessionRunner progress={progress} onFinish={onFinish} onCancel={vi.fn()} />);

    // Station 1: disiplin (checklist)
    fireEvent.click(screen.getByText('Sudah, lanjut'));

    // Station 2: insting (choice) — level 1 content has two choices
    const choiceButtons = await screen.findAllByRole('button');
    const optionButton = choiceButtons.find((b) => b.textContent?.includes('kantin favorit'));
    expect(optionButton).toBeDefined();
    fireEvent.click(optionButton!);

    // Stations 3-5 are text inputs
    for (let i = 0; i < 3; i++) {
      const textarea = screen.getByPlaceholderText('Tulis di sini...');
      fireEvent.change(textarea, { target: { value: 'jawaban test' } });
      fireEvent.click(screen.getByRole('button', { name: /Lanjut|Selesaikan Sesi/ }));
      await waitFor(() => {}); // let state settle between stations
    }

    await waitFor(() => expect(onFinish).toHaveBeenCalledTimes(1));
    const [nextProgress] = onFinish.mock.calls[0];
    expect(nextProgress.currentLevel).toBe(1);
  });
});

describe('SessionRunner — dynamic levels (6+)', () => {
  beforeEach(async () => {
    await resetAllData();
    mockedCallCoach.mockReset();
  });

  function progressAtLevel(n: number) {
    return { ...createInitialProgressState(), currentLevel: n, lastAdvancedDate: '2026-06-01' };
  }

  it('shows a loading state before the AI Coach responds', () => {
    mockedCallCoach.mockReturnValue(new Promise(() => {})); // never resolves
    render(<SessionRunner progress={progressAtLevel(6)} onFinish={vi.fn()} onCancel={vi.fn()} />);
    expect(screen.getByText(/menyiapkan sesi/)).toBeInTheDocument();
  });

  it('renders the parsed dynamic content once the AI Coach responds successfully', async () => {
    mockedCallCoach.mockResolvedValue(validDynamicPayload());
    render(<SessionRunner progress={progressAtLevel(6)} onFinish={vi.fn()} onCancel={vi.fn()} />);
    await waitFor(() => expect(screen.getByText('Sudah minum air?')).toBeInTheDocument());
    expect(mockedCallCoach).toHaveBeenCalledTimes(1);
  });

  it('shows the API-key error message and offers Retry + fallback when the AI Coach call fails', async () => {
    mockedCallCoach.mockRejectedValue(
      new CoachClientError('Belum ada Anthropic API key tersimpan. Buka Pengaturan → AI Coach.')
    );
    render(<SessionRunner progress={progressAtLevel(6)} onFinish={vi.fn()} onCancel={vi.fn()} />);
    await waitFor(() => expect(screen.getByText(/Belum ada Anthropic API key/)).toBeInTheDocument());
    expect(screen.getByText('Coba Lagi')).toBeInTheDocument();
    expect(screen.getByText('Pakai pola default untuk hari ini')).toBeInTheDocument();
  });

  it('falls back to the Level 5 static pattern, explicitly, when the user taps the fallback button', async () => {
    mockedCallCoach.mockRejectedValue(new CoachClientError('gagal'));
    render(<SessionRunner progress={progressAtLevel(6)} onFinish={vi.fn()} onCancel={vi.fn()} />);
    await waitFor(() => expect(screen.getByText('Pakai pola default untuk hari ini')).toBeInTheDocument());
    fireEvent.click(screen.getByText('Pakai pola default untuk hari ini'));
    expect(await screen.findByText(/pola default/)).toBeInTheDocument();
  });

  it('shows a format error (not a crash) when the AI Coach returns malformed JSON', async () => {
    mockedCallCoach.mockResolvedValue('maaf, saya tidak bisa membuat sesi ini');
    render(<SessionRunner progress={progressAtLevel(6)} onFinish={vi.fn()} onCancel={vi.fn()} />);
    await waitFor(() => expect(screen.getByText(/tidak sesuai format/)).toBeInTheDocument());
  });
});
