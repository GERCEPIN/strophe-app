import { useEffect, useState } from 'react';
import type { ProgressState, SessionStationResult, DailyCoreSession } from '../types';
import { getLevelContent, type LevelContent } from '../content/coreSessionLevels';
import { completeTodaysSession } from '../engine/dailyTransition';
import { progressStore, sessionStore } from '../storage/db';
import { callCoach, CoachClientError } from '../coach/client';
import { dynamicLevelContentPrompt } from '../coach/promptTemplates';
import { parseDynamicLevelContent, DynamicContentParseError } from '../coach/parseDynamicContent';

interface SessionRunnerProps {
  progress: ProgressState;
  onFinish: (next: ProgressState) => void;
  onCancel: () => void;
}

/**
 * Levels 1-5 use hand-authored content (instant, no network). Level 6+
 * calls the AI Coach for a freshly generated session — see
 * coach/promptTemplates.ts#dynamicLevelContentPrompt and
 * TECHNICAL_SPEC.md §4 ("Phase 2 item 1" in CLAUDE.md, now implemented).
 */
const STATIC_MAX_LEVEL = 5;

function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

export function SessionRunner({ progress, onFinish, onCancel }: SessionRunnerProps) {
  const level = progress.currentLevel + 1;
  const isDynamicLevel = level > STATIC_MAX_LEVEL;

  const [content, setContent] = useState<LevelContent | null>(
    isDynamicLevel ? null : getLevelContent(level)
  );
  const [loading, setLoading] = useState(isDynamicLevel);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [stationIndex, setStationIndex] = useState(0);
  const [responses, setResponses] = useState<SessionStationResult[]>([]);
  const [draft, setDraft] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (isDynamicLevel) void loadDynamicContent();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [level]);

  async function loadDynamicContent() {
    setLoading(true);
    setLoadError(null);
    try {
      const recentThemes = await sessionStore.recentInstingThemes(5);
      const prompt = dynamicLevelContentPrompt(level, recentThemes);
      const raw = await callCoach(prompt, 900);
      const parsed = parseDynamicLevelContent(raw, level, `Putaran ${level}`);
      setContent(parsed);
    } catch (err) {
      if (err instanceof CoachClientError) {
        setLoadError(err.message);
      } else if (err instanceof DynamicContentParseError) {
        setLoadError(`AI Coach memberi jawaban tidak sesuai format (${err.message})`);
      } else {
        setLoadError('Gagal memuat sesi hari ini. Periksa koneksi internet.');
      }
    } finally {
      setLoading(false);
    }
  }

  function useFallbackContent() {
    // Explicit, visible fallback — chosen by the user, never silent.
    setContent({ ...getLevelContent(STATIC_MAX_LEVEL), level, title: `Putaran ${level} (pola default)` });
    setLoadError(null);
  }

  function recordAndAdvance(partial: Partial<SessionStationResult>, instructionShown: string) {
    if (!content) return;
    const station = content.stations[stationIndex];
    const result: SessionStationResult = {
      station: station.station,
      completedAt: new Date().toISOString(),
      instructionShown,
      ...partial,
    };
    const nextResponses = [...responses, result];
    setResponses(nextResponses);
    setDraft('');
    const isLast = stationIndex === content.stations.length - 1;
    if (isLast) {
      void finish(nextResponses);
    } else {
      setStationIndex((i) => i + 1);
    }
  }

  async function finish(finalResponses: SessionStationResult[]) {
    if (!content) return;
    setSaving(true);
    const today = todayStr();
    const { state: nextProgress } = completeTodaysSession(progress, today);
    await progressStore.set(nextProgress);
    const session: DailyCoreSession = {
      date: today,
      level: content.level,
      stations: finalResponses,
      completed: true,
    };
    await sessionStore.put(session);
    setSaving(false);
    onFinish(nextProgress);
  }

  if (loading) {
    return (
      <div className="screen">
        <p className="eyebrow">Putaran {level}</p>
        <div className="card">
          <p style={{ color: 'var(--text-dim)', fontSize: 15 }}>
            AI Coach sedang menyiapkan sesi hari ini...
          </p>
        </div>
        <button className="btn-secondary" onClick={onCancel}>
          Nanti dulu
        </button>
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="screen">
        <p className="eyebrow">Putaran {level}</p>
        <div className="banner-warning">{loadError}</div>
        <button className="btn-primary" onClick={() => void loadDynamicContent()}>
          Coba Lagi
        </button>
        <button className="btn-secondary" onClick={useFallbackContent}>
          Pakai pola default untuk hari ini
        </button>
        <button className="btn-secondary" onClick={onCancel}>
          Nanti dulu
        </button>
      </div>
    );
  }

  if (!content) return null;

  const station = content.stations[stationIndex];
  const isLast = stationIndex === content.stations.length - 1;

  return (
    <div className="screen">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <p className="eyebrow">
          Putaran {level} · {content.title}
        </p>
        <button className="btn-secondary" onClick={onCancel}>
          Nanti dulu
        </button>
      </div>

      <div style={{ display: 'flex', gap: 6 }} aria-hidden="true">
        {content.stations.map((s, i) => (
          <div
            key={s.station}
            style={{
              flex: 1,
              height: 4,
              borderRadius: 2,
              background: i <= stationIndex ? 'var(--gold)' : 'var(--border)',
            }}
          />
        ))}
      </div>

      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div>
          <p className="eyebrow" style={{ marginBottom: 6 }}>
            {station.title}
            {station.timeLimitSeconds ? ` · ${station.timeLimitSeconds} detik` : ''}
          </p>
          <p style={{ color: 'var(--text-dim)', fontSize: 15.5, lineHeight: 1.55 }}>
            {station.instruction}
          </p>
        </div>

        {station.inputType === 'checklist' && (
          <button
            className="btn-primary"
            onClick={() => recordAndAdvance({ freeTextResponse: 'done' }, station.instruction)}
            disabled={saving}
          >
            Sudah, lanjut
          </button>
        )}

        {station.inputType === 'choice' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {station.choices?.map((choice) => (
              <button
                key={choice}
                className="btn-secondary"
                onClick={() => recordAndAdvance({ freeTextResponse: choice }, station.instruction)}
                disabled={saving}
              >
                {choice}
              </button>
            ))}
          </div>
        )}

        {(station.inputType === 'text' || station.inputType === 'findIssues') && (
          <>
            <textarea
              rows={4}
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder="Tulis di sini..."
            />
            <button
              className="btn-primary"
              onClick={() => recordAndAdvance({ freeTextResponse: draft }, station.instruction)}
              disabled={saving || !draft.trim()}
            >
              {isLast ? 'Selesaikan Sesi' : 'Lanjut'}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
