import { describe, it, expect, beforeEach } from 'vitest';
import { progressStore, memoryVaultStore, sessionStore, resetAllData } from './db';
import { createInitialProgressState } from '../engine/level';
import { createMemoryVaultItem } from '../engine/memoryVault';

describe('storage/db', () => {
  beforeEach(async () => {
    await resetAllData();
  });

  it('round-trips a ProgressState through IndexedDB', async () => {
    const state = { ...createInitialProgressState(), currentLevel: 5, mentalScore: 82 };
    await progressStore.set(state);
    const loaded = await progressStore.get();
    expect(loaded).toEqual(state);
  });

  it('returns undefined when nothing has been stored yet', async () => {
    const loaded = await progressStore.get();
    expect(loaded).toBeUndefined();
  });

  it('overwrites the previous value when set is called again (singleton semantics)', async () => {
    await progressStore.set({ ...createInitialProgressState(), currentLevel: 1 });
    await progressStore.set({ ...createInitialProgressState(), currentLevel: 2 });
    const loaded = await progressStore.get();
    expect(loaded?.currentLevel).toBe(2);
  });

  it('stores memory vault items and queries only those due on or before a given date', async () => {
    const dueSoon = createMemoryVaultItem('a', 'payung', '2026-07-01');
    const dueLater = { ...createMemoryVaultItem('b', 'sendok', '2026-07-01'), dueDate: '2026-07-20' };
    await memoryVaultStore.put(dueSoon);
    await memoryVaultStore.put(dueLater);

    const due = await memoryVaultStore.dueBy('2026-07-05');
    expect(due.map((i) => i.id)).toEqual(['a']);

    const all = await memoryVaultStore.all();
    expect(all).toHaveLength(2);
  });

  it('round-trips a DailyCoreSession and retrieves it by date', async () => {
    const session = {
      date: '2026-07-01',
      level: 6,
      completed: true,
      stations: [
        {
          station: 'insting' as const,
          completedAt: '2026-07-01T08:00:00.000Z',
          instructionShown: 'Rapat mendadak dimajukan.',
          freeTextResponse: 'Datang tanpa persiapan penuh',
        },
      ],
    };
    await sessionStore.put(session);
    const loaded = await sessionStore.get('2026-07-01');
    expect(loaded).toEqual(session);
  });

  it('recentInstingThemes returns the most recent Insting instructions, newest first, truncated', async () => {
    const longInstruction = 'x'.repeat(120);
    for (const [date, instruction] of [
      ['2026-07-01', 'Skenario hari 1'],
      ['2026-07-02', 'Skenario hari 2'],
      ['2026-07-03', longInstruction],
    ] as const) {
      await sessionStore.put({
        date,
        level: 1,
        completed: true,
        stations: [
          {
            station: 'insting',
            completedAt: `${date}T08:00:00.000Z`,
            instructionShown: instruction,
            freeTextResponse: 'x',
          },
        ],
      });
    }

    const themes = await sessionStore.recentInstingThemes(2);
    expect(themes).toHaveLength(2);
    expect(themes[0].length).toBeLessThanOrEqual(60); // truncated
    expect(themes[0].startsWith('x')).toBe(true); // most recent (07-03) first
  });

  it('recentInstingThemes returns an empty array when there is no session history yet', async () => {
    const themes = await sessionStore.recentInstingThemes();
    expect(themes).toEqual([]);
  });
});
