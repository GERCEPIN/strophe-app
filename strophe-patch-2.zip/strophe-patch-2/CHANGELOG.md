# Changelog

## Unreleased — Dynamic content generation for level 6+ (Phase 2 item 1)

Levels 1-5 stay hand-authored. From level 6 onward, `SessionRunner` now
calls the AI Coach for a freshly generated 5-station session instead of
silently recycling Level 5's content.

### Yang berubah

- **`coach/promptTemplates.ts`** — tambah `dynamicLevelContentPrompt`,
  menghasilkan seluruh 5 stasiun dalam **satu** panggilan API (bukan 5
  panggilan terpisah) — lebih cepat dimuat dan lebih sederhana ditangani
  errornya (sukses/gagal atomik).
- **`coach/parseDynamicContent.ts`** (baru) — parser defensif: coba
  ekstrak JSON walau model membungkusnya dengan kalimat pembuka/penutup,
  lalu validasi field demi field (jumlah stasiun, urutan nama stasiun,
  instruksi tidak kosong, `inputType` dikenal, `choices` minimal 2 untuk
  tipe `choice`). Tiap mode kegagalan punya pesan error spesifik, bukan
  cuma "terjadi kesalahan".
- **`SessionRunner.tsx`** — level 6+ sekarang: tampilkan status memuat →
  panggil AI Coach → kalau berhasil, tampilkan hasilnya; kalau gagal
  (API key belum diisi, koneksi putus, atau JSON tidak valid), tampilkan
  pesan error spesifik + tombol **Coba Lagi** + tombol **Pakai pola
  default** (fallback ke Level 5, tapi selalu berupa pilihan eksplisit
  user, tidak pernah diam-diam terjadi).
- **`types/index.ts`** — `SessionStationResult` sekarang wajib punya
  `instructionShown` (instruksi persis yang ditampilkan saat itu),
  supaya sesi hari-hari sebelumnya bisa dibaca ulang untuk menghindari
  tema berulang.
- **`storage/db.ts`** — tambah `sessionStore.recentInstingThemes()`,
  dipakai untuk mengisi bagian "jangan ulangi tema ini" di prompt.

### Verifikasi

**69 test lolos** (naik dari 48 — nambah 11 test parser yang menutup
setiap mode kegagalan JSON, 7 test komponen `SessionRunner` yang menutup
jalur statis/loading/sukses/error/fallback, 3 test `sessionStore` yang
sebelumnya nol coverage). Build produksi (`npm run build`) dan linter
(`npx oxlint`) tetap bersih setelah perubahan ini.


Logo asli STROPHE (diunggah sebagai `1000316743.jpg`, mark abstrak hitam
gaya garis/blob yang melambangkan simpul-simpul yang saling terhubung —
selaras dengan konsep "titik balik") sekarang jadi identitas visual nyata
aplikasi, menggantikan spiral placeholder yang saya buat sebelumnya di
Phase 1.

### Yang berubah

- **Diolah dari 1 file JPEG 1280×1280 (hitam di atas putih) jadi 6 aset
  ikon PNG**, lewat threshold + trim + rekolorisasi terprogram (bukan
  ditelusuri manual) — lihat `scripts/` note di bawah kalau proses ini
  perlu diulang untuk logo versi lain nanti.
- **Direkolorisasi dari hitam ke emas (`#C9A24B`)** supaya konsisten
  dengan token desain yang sudah dipakai di seluruh app (`index.css`,
  `LevelSpiral.tsx`) — mark hitam di atas latar gelap aplikasi akan
  nyaris tak terlihat, jadi ini bukan sekadar preferensi, tapi keperluan
  kontras.
- **Dua varian dibuat, sesuai spesifikasi PWA manifest:**
  - `icon-any-*.png` — latar transparan, isi ~85% kanvas (dipakai untuk
    konteks yang tidak di-crop OS).
  - `icon-maskable-*.png` — latar solid `#0B0B0F`, isi mark dikecilkan
    ke ~55-58% kanvas supaya aman di dalam *safe zone* ~80% yang
    disyaratkan spesifikasi maskable icon — Android boleh memotongnya
    jadi lingkaran/rounded-square, mark tidak akan terpotong.
  - Plus `apple-touch-icon.png` (180×180, gaya sama dengan maskable) dan
    `favicon.png` (48×48).
- **`vite.config.ts`** — manifest icons array diupdate menunjuk ke PNG
  asli dengan `purpose: 'any'` / `'maskable'` yang benar (sebelumnya satu
  SVG placeholder dipakai untuk keduanya sekaligus, yang secara teknis
  tidak ideal untuk maskable).
- **`index.html`** — favicon & apple-touch-icon link diarahkan ke aset
  baru.
- **`Onboarding.tsx` & `Dashboard.tsx`** — mark logo asli sekarang tampil
  langsung di header, bukan cuma jadi ikon aplikasi di home screen.
- Placeholder SVG lama (`icon-192.svg`, `icon-512.svg`, `favicon.svg`)
  dihapus dari `public/`.

### Verifikasi

Karena image viewer sempat gagal saat proses ini (masalah tool
sementara, bukan masalah file — sudah dicoba ulang beberapa kali), setiap
ikon diverifikasi programatis, bukan cuma "dijalankan tanpa error":
posisi bounding box mark emas dihitung ulang untuk memastikan benar-benar
center (offset ≤1px dari titik tengah kanvas di semua ukuran) dan
proporsi kanvas yang terisi sesuai target (any ~85%, maskable ~55-58%).
Setelah itu, `npm run build` dicek ulang untuk memastikan
`manifest.webmanifest` dan `dist/index.html` benar-benar mereferensikan
file yang benar dan filenya benar-benar tersalin ke `dist/` — bukan
diasumsikan.

`npm test` (48/48) dan `npx oxlint` (0 error) dijalankan ulang setelah
perubahan ini dan tetap hijau.
